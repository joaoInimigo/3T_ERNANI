//crie um programa que cheque usuario e senha
//caso o usuario e senha sejam iguais ao cadastro, exiba uma mensagem de sucesso
//caso contrario, pergunte novamente (while)
const usuario = "admin"
const senha = "12345"
let u, s = ""
let estaLogado = false

while (!estaLogado){
  u = prompt("Digite o usuario")
  s = prompt("Digite a senha")
  if (u == usuario && s == senha) {
    window.alert("Seja bem vindo" + usuario)
    estaLogado = true 
  } else {
    window.alert("Usuario ou senha invalidos. Tente novamente")
  } 
}
