//operador ternário serve para
//desvio condicional, assim como o if/else, porém sua sintaxe simplificada
//podemos utilizar o operador ternário aninhado
//exemplo: <variável> = <condição> ? <valor_verdadeiro> : <valor_falso>

const idade = 18

const cnh = idade >= 18 ? "Maiores podem dirigir": "Proibido dirigir"
console.log(cnh)

let pessoas = [
  {nome: "Ana", sexo: "F", idade: 15},
  {nome: "Martelinho de Ouro", sexo: "M", idade: 33},
  {nome: "Leonarda", sexo: "F", idade: 17},
  {nome: "Clovis", sexo: "M", idade: 11}
]
let meninas = []
let meninos = []
for (let nome of pessoas){
  nome.sexo == "F" ? meninas.push(nome) : meninos.push(nome)
}
console.table(meninas)
console.table(meninos)
 