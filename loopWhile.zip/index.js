//LOOP WHILE (ENQUANTO)
//RODA NUM LOOP INFINITO POR PADRÃO
//MAS PODEMOS ESTIMULAR UMA INFORMAÇÃO
//DE PARADA PARA CONTROLÁ-LO
//SÍNTAXE: WHILE (CONDIÇÃO) {CÓDIGO}
let n = 0;
while (n < 69) {
  //console.clear()
  if (n % 2 == 1) {
    console.log(n)
  }
  n = n + 1
}
