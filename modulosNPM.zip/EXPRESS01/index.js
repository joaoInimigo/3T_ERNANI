const express = require('express');
const app = express(); // CRIADO UMA INSTÃNCIA DE EXPRESS

const PORT = 33333;

app.get("/", function (req, res){
  res.send("Hello Página Home");
});
app.get("/sobre", function (req, res){
  res.send("<h1>Página Sobre</h1>");
});

app.listen(PORT, function () {
  console.log("Rodando na porta: " + PORT);
});
