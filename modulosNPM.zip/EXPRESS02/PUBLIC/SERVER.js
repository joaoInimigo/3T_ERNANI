//  CRIAR NOSSO SERVIDOR
const express = require("express");
const path = require("path");
const app = express();

// CRIAR ROTAS
app.get("/", function (req, res) {
  // NOSSO CÓDIGO AQUI...
});

// USAR O SERVIDOR NUMA DADA PORTA
app.listen(3000, function ()
