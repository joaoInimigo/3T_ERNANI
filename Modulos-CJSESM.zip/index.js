import { criarPasta } from "./modulo_fs/lib/fs_mkdir.cjs";

criarPasta("./relatorios")
criarPasta("./documentos");
