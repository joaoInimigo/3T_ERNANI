/** CRIE UM ARRAY DE OBJETOS => PESSOAS
 *  COM OS SEGUINTES ATRIBUTOS: NOME/SOBRENOME
 * CRIE UMA FUNÇÃO QUE ITERE SOBRE O ARRAY
 * E RETIRE NOMES E SOBRENOMES
 * CRIE UMA VARIÁVEL COM O CONTEÚDO:
 *      -> const emailBase = "@escola.pr.gov.br"
 * A PARTIR DESSES DADOS FORME UM @escola com
 * NOME, SOBRE+EMAILBASE
 * EXECUTE A FUNÇÃO...
 */
const pessoas = [
{nome: "Zico", sobrenome: "Tejano"},
{nome: "Ícaro", sobrenome: "Heróico"},
{nome: "Frederico", sobrenome: "Pessoa"}
];

for (pessoa of pessoas) {




  

