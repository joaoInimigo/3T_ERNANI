
import { acelerar } from './lib/veiculo.js';

import { mostrarDadosVeiculo } from './lib/veiculo.js';

import {fs} from "./lib/require.cjs";

console.log(mostrarDadosVeiculo());

console.log(acelerar());

console.log(fs);

