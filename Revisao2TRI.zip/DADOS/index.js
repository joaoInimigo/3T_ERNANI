// arrays são indexado]
// possuem métodos
// podem ser iterados
const nome = "Bendito";
const time = ["Kesloy", "Marinho", "Mané Galinha", "Senseio", "Catatodas"];
//(PARENTESES), [COLCHETES], {CHAVES}
time.push("Italo"); // SEMPRE NO FINAL DA LISTA
time.shift(); // REMOVE ALGUÉM NO INÍCIO
console.log(time);
console.log(time[2]); // José
console.log(time[20]); // undefined
time[20] = "Piratiado";
console.log(time[20]); // Piratiado
// ITERAR - LOOP ATÉ O ESGOTAMENTO (FOR, FOREACH, WHILE, FOR IN, FOR OF)
for (var i = 0; i <= 4; i++) {
  console.log(time[i]);
}
console.log(time)